<html>
    <head>
        <title>Abducted</title>
    </head>
    <body>


<?php

$fname = $_POST['firstname'];
$lname = $_POST['lastname'];
$howmany = $_POST['howmany'];
$whatdone = $_POST['whattheydid'];
$other = $_POST['other'];



echo "Thank you for submiting the form";
echo "You were abducted " . $_POST['whenithappened'];
echo " and were gone for " . $_POST['howlong'] . "<br>";
echo "Describe them: " . $_POST['aliendescription'] . "<br>";
echo "Was fang there? " . $_POST['fangspotted'];
echo "Your email address is " . $_POST['email'];

$msg = $fname . " " . $lname . " Was Abducted " . $_POST['whenithappened'] . " And was gone for " . $_POST['howlong'] . " #Aliens " . $howmany . " Discript: " . $_POST['aliendescription'] . " What they did " 
. $whatdone . " Fang Spotterd " . $_POST['fangspotted'] . " Other: " . $other;

$subject = "Aliens Abducted Me - Report";
$email = $_POST['email'];
$to = "mmurray@minuteman.org";

mail($to, $subject, $msg);


?>

    </body>
</html>
